# noqa: C801
__version__ = "0.0.15+f351fee.d20221221"
